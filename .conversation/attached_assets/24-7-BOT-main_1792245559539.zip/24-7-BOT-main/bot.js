// Import the mineflayer library
const mineflayer = require('mineflayer');
// Import the built-in http module
const http = require('http');
const crypto = require('crypto');

// Server connection details
const host = 'THUNDERBALLYT.aternos.me';
const port = 46830;
const username = '.'; // New bot username for this version

// Initial teleport coordinates
const startX = 49;
const startY = 64;
const startZ = 49;

// Teleport interval settings
const shortIntervalMs = 60 * 1000; // 60 seconds
const longIntervalMs = 60 * 60 * 1000; // 60 minutes
const reconnectDelayMs = 10 * 1000;
const restartCooldownMs = 30 * 1000;
const isPublishedDeployment = process.env.REPLIT_DEPLOYMENT === '1';

let bot; // Declare bot variable globally
let shortTeleportInterval;
let longTeleportTimeout;
let reconnectTimeout;
let restartFallbackTimeout;
let restartInProgress = false;
let lastManualRestartAt = 0;
let botStatus = 'Initializing...'; // Bot status for HTTP server
let botPosition = 'N/A'; // Bot position for HTTP server

function scheduleReconnect(delay = reconnectDelayMs) {
    if (!isPublishedDeployment) return;
    clearTimeout(reconnectTimeout);
    reconnectTimeout = setTimeout(() => {
        reconnectTimeout = undefined;
        createBot();
    }, delay);
}

/**
 * Creates and connects the Minecraft bot.
 */
function createBot() {
    if (!isPublishedDeployment || bot) return;
    clearTimeout(reconnectTimeout);
    reconnectTimeout = undefined;

    console.log(`Attempting to connect to ${host}:${port} as ${username}...`);
    botStatus = `Attempting to connect to ${host}:${port}`;

    const botOptions = {
        host: host,
        port: port,
        username: username,
        version: false, // Set to false to enable auto-detection of Minecraft version
        checkTimeoutInterval: 60 * 1000 // Increase timeout to 60 seconds (default is 10s) for stability
    };

    console.log('Attempting to auto-detect Minecraft version...');

    const currentBot = mineflayer.createBot(botOptions);
    bot = currentBot;

    // --- Bot Event Listeners ---

    currentBot.on('spawn', () => {
        if (bot !== currentBot) return;
        console.log(`${username} has spawned!`);
        botStatus = 'Connected and spawned';
        updateBotPosition(); // Update position immediately
        // Teleport to the initial position
        teleportToStart();

        // Clear any previous intervals/timeouts to prevent duplicates
        clearInterval(shortTeleportInterval);
        clearTimeout(longTeleportTimeout);

        // Start the short teleport interval (every 60 seconds)
        shortTeleportInterval = setInterval(() => {
            teleportByX(10); // Teleport 10 blocks in X
            updateBotPosition(); // Update position after teleport
        }, shortIntervalMs);

        // Schedule the long teleport back and disconnect/reconnect (every 60 minutes)
        longTeleportTimeout = setTimeout(() => {
            console.log('60 minutes passed. Teleporting back to start, disconnecting, and reconnecting...');
            botStatus = 'Scheduled disconnect and reconnect';
            teleportToStart().then(() => {
                // Give a small delay before disconnecting to ensure teleport command is sent
                setTimeout(() => {
                    bot.quit('Time for a refresh!');
                }, 1000);
            });
        }, longIntervalMs);
    });

    // Event listener for chat messages (optional, for debugging)
    currentBot.on('chat', (chatUsername, message) => {
        if (chatUsername === currentBot.username) return; // Ignore own messages
        console.log(`${chatUsername}: ${message}`);
    });

    currentBot.on('kicked', (reason, loggedIn) => {
        console.error(`${username} was kicked by the server. Logged in: ${loggedIn}. Reason:`, reason);
    });

    // Event listener for when the bot disconnects
    currentBot.on('end', (reason) => {
        if (bot !== currentBot) return;
        console.log(`${username} disconnected. Reason: ${reason}`);
        const wasRestartRequested = restartInProgress;
        bot = undefined;
        restartInProgress = false;
        clearTimeout(restartFallbackTimeout);
        restartFallbackTimeout = undefined;
        botStatus = wasRestartRequested
            ? `Restart requested; reconnecting in ${reconnectDelayMs / 1000} seconds`
            : `Disconnected: ${reason}`;
        botPosition = 'N/A'; // Reset position when disconnected
        // Clear all active intervals/timeouts
        clearInterval(shortTeleportInterval);
        clearTimeout(longTeleportTimeout);
        console.log(`Attempting to reconnect in ${reconnectDelayMs / 1000} seconds...`);
        scheduleReconnect();
    });

    // Event listener for errors
    currentBot.on('error', (err) => {
        if (bot !== currentBot) return;
        console.error(`${username} encountered an error:`, err);
        botStatus = `Error: ${err.message}`;
        // The 'end' event will usually follow an error, handling reconnection
    });

    // Event listener for position updates
    currentBot.on('move', () => {
        if (bot !== currentBot) return;
        updateBotPosition();
    });
}

/**
 * Teleports the bot to the initial start coordinates.
 * @returns {Promise<void>} A promise that resolves when the teleport command is sent.
 */
async function teleportToStart() {
    // Only attempt teleport if bot.entity.position exists (bot is spawned)
    if (bot.entity && bot.entity.position) {
        const position = bot.entity.position;
        if (position.x !== startX || position.y !== startY || position.z !== startZ) {
            console.log(`Teleporting to initial position: ${startX}, ${startY}, ${startZ}`);
            try {
                await bot.chat(`/tp ${startX} ${startY} ${startZ}`);
                console.log(`Teleported to ${startX}, ${startY}, ${startZ}`);
                updateBotPosition(); // Update position after successful teleport
            } catch (err) {
                console.error('Failed to teleport to start:', err.message);
            }
        } else {
            console.log('Already at start position.');
        }
    } else {
        console.log('Bot entity position not available yet. Skipping initial teleport.');
    }
}

/**
 * Teleports the bot by a specified amount in the X direction.
 * @param {number} amount The amount to teleport in the X direction.
 * @returns {Promise<void>} A promise that resolves when the teleport command is sent.
 */
async function teleportByX(amount) {
    // Only attempt teleport if bot.entity.position exists (bot is spawned)
    if (bot.entity && bot.entity.position) {
        const currentX = bot.entity.position.x;
        const currentY = bot.entity.position.y;
        const currentZ = bot.entity.position.z;
        const newX = currentX + amount;

        console.log(`Teleporting from ${currentX},${currentY},${currentZ} to ${newX},${currentY},${currentZ}`);
        try {
            await bot.chat(`/tp ${newX} ${currentY} ${currentZ}`);
            console.log(`Teleport command sent for ${newX}, ${currentY}, ${currentZ}`);
            updateBotPosition(); // Update position after successful teleport
        } catch (err) {
            console.error('Failed to teleport by X:', err.message);
        }
    } else {
        console.log('Bot entity position not available yet. Skipping X teleport.');
    }
}

/**
 * Updates the global botPosition variable.
 */
function updateBotPosition() {
    if (bot && bot.entity && bot.entity.position) {
        const pos = bot.entity.position;
        botPosition = `X: ${pos.x.toFixed(1)}, Y: ${pos.y.toFixed(1)}, Z: ${pos.z.toFixed(1)}`;
    } else {
        botPosition = 'N/A (Bot not spawned or disconnected)';
    }
}

function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (character) => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    })[character]);
}

function sendJson(res, statusCode, payload) {
    res.writeHead(statusCode, {
        'Content-Type': 'application/json; charset=utf-8',
        'Cache-Control': 'no-store'
    });
    res.end(JSON.stringify(payload));
}

function hasAdminPassword() {
    return Boolean(process.env.BOT_ADMIN_PASSWORD) &&
        Buffer.byteLength(process.env.BOT_ADMIN_PASSWORD, 'utf8') >= 16;
}

function isAuthorizedForRestart(req) {
    const password = process.env.BOT_ADMIN_PASSWORD;
    const authorization = req.headers.authorization || '';
    const token = authorization.toLowerCase().startsWith('bearer ')
        ? authorization.slice(7)
        : '';
    if (!password || !token) return false;

    const provided = Buffer.from(token, 'utf8');
    const expected = Buffer.from(password, 'utf8');
    return provided.length === expected.length && crypto.timingSafeEqual(provided, expected);
}

function requestBotRestart() {
    const now = Date.now();
    if (restartInProgress) {
        return { statusCode: 409, message: 'A bot restart is already in progress.' };
    }

    const elapsedSinceRestart = now - lastManualRestartAt;
    if (lastManualRestartAt && elapsedSinceRestart < restartCooldownMs) {
        const remainingSeconds = Math.ceil((restartCooldownMs - elapsedSinceRestart) / 1000);
        return { statusCode: 429, message: `Please wait ${remainingSeconds} seconds before restarting again.` };
    }

    lastManualRestartAt = now;
    clearTimeout(reconnectTimeout);
    reconnectTimeout = undefined;

    if (!bot) {
        botStatus = `Restart requested; reconnecting in ${reconnectDelayMs / 1000} seconds`;
        scheduleReconnect();
        return { statusCode: 202, message: botStatus };
    }

    const botBeingRestarted = bot;
    restartInProgress = true;
    botStatus = 'Restart requested; disconnecting the current session...';

    restartFallbackTimeout = setTimeout(() => {
        if (bot !== botBeingRestarted) return;

        console.warn('Bot did not disconnect after a restart request; forcing its connection closed.');
        try {
            botBeingRestarted.end('Manual restart fallback');
        } catch (error) {
            console.error('Could not close the bot connection cleanly:', error.message);
        }

        if (bot === botBeingRestarted) {
            bot = undefined;
            restartInProgress = false;
            clearInterval(shortTeleportInterval);
            clearTimeout(longTeleportTimeout);
            botStatus = `Restart requested; reconnecting in ${reconnectDelayMs / 1000} seconds`;
            scheduleReconnect();
        }
    }, 5000);

    try {
        botBeingRestarted.quit('Manual restart requested');
        return {
            statusCode: 202,
            message: `Restart requested; the bot will reconnect in about ${reconnectDelayMs / 1000} seconds.`
        };
    } catch (error) {
        clearTimeout(restartFallbackTimeout);
        restartFallbackTimeout = undefined;
        restartInProgress = false;
        botStatus = `Restart failed: ${error.message}`;
        console.error('Could not restart the bot:', error);
        scheduleReconnect();
        return { statusCode: 500, message: 'Could not close the current bot connection. A reconnect was scheduled.' };
    }
}


// --- HTTP Server Setup ---
const PORT = process.env.PORT || 5000;

const server = http.createServer((req, res) => {
    const pathname = (req.url || '/').split('?')[0];

    if (pathname === '/health') {
        if (req.method !== 'GET') {
            res.writeHead(405, { 'Allow': 'GET', 'Content-Type': 'text/plain; charset=utf-8' });
            res.end('Method not allowed');
            return;
        }
        const connected = botStatus === 'Connected and spawned';
        res.writeHead(connected ? 200 : 503, {
            'Content-Type': 'text/plain; charset=utf-8',
            'Cache-Control': 'no-store'
        });
        res.end(connected ? 'Minecraft bot connected' : `Minecraft bot unavailable: ${botStatus}`);
        return;
    }

    if (pathname === '/favicon.ico') {
        res.writeHead(204, { 'Cache-Control': 'public, max-age=86400' });
        res.end();
        return;
    }

    if (pathname === '/status') {
        if (req.method !== 'GET') {
            sendJson(res, 405, { message: 'Method not allowed.' });
            return;
        }
        sendJson(res, 200, { status: botStatus, position: botPosition });
        return;
    }

    if (pathname === '/restart') {
        if (req.method !== 'POST') {
            res.writeHead(405, { 'Allow': 'POST', 'Content-Type': 'text/plain; charset=utf-8' });
            res.end('Method not allowed');
            return;
        }
        if (!isPublishedDeployment) {
            sendJson(res, 404, { message: 'Bot restart is only available in the published deployment.' });
            return;
        }
        if (!hasAdminPassword()) {
            sendJson(res, 503, { message: 'Set a BOT_ADMIN_PASSWORD of at least 16 characters in Replit Secrets to enable restarts.' });
            return;
        }
        if (!isAuthorizedForRestart(req)) {
            sendJson(res, 401, { message: 'The admin password is incorrect.' });
            return;
        }

        const result = requestBotRestart();
        sendJson(res, result.statusCode, { message: result.message });
        return;
    }

    if (pathname !== '/' || req.method !== 'GET') {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Not found');
        return;
    }

    const canRestart = isPublishedDeployment && hasAdminPassword();
    const restartHint = !isPublishedDeployment
        ? 'Restart controls are available in the published deployment.'
        : !hasAdminPassword()
            ? 'Set a BOT_ADMIN_PASSWORD of at least 16 characters in Replit Secrets to enable restarts.'
            : 'Enter the admin password to restart the bot. Restarts are limited to once every 30 seconds.';

    res.writeHead(200, {
        'Content-Type': 'text/html; charset=utf-8',
        'Cache-Control': 'no-store'
    });
    res.end(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Universal Teleport Bot Status</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; background-color: #f4f4f4; color: #333; }
                .container { background-color: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
                h1 { color: #0056b3; }
                h2 { margin-top: 28px; color: #0056b3; }
                p { margin-bottom: 10px; }
                strong { color: #007bff; }
                .restart-controls { margin-top: 24px; padding-top: 18px; border-top: 1px solid #ddd; }
                .restart-row { display: flex; flex-wrap: wrap; gap: 10px; align-items: center; }
                input, button { box-sizing: border-box; min-height: 42px; padding: 9px 12px; font: inherit; }
                input { width: min(100%, 320px); border: 1px solid #aaa; border-radius: 5px; }
                .visually-hidden { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0, 0, 0, 0); white-space: nowrap; border: 0; }
                button { color: #fff; background: #0056b3; border: 0; border-radius: 5px; cursor: pointer; }
                button:disabled { background: #8798a8; cursor: not-allowed; }
                #restartMessage { min-height: 1.4em; }
                @media (max-width: 520px) { .restart-row { align-items: stretch; flex-direction: column; } }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>Universal Teleport Bot Status</h1>
                <p><strong>Bot Name:</strong> ${escapeHtml(username)}</p>
                <p><strong>Minecraft Server:</strong> ${escapeHtml(host)}:${escapeHtml(port)}</p>
                <p><strong>Status:</strong> <span id="botStatus">${escapeHtml(botStatus)}</span></p>
                <p><strong>Current Position:</strong> <span id="botPosition">${escapeHtml(botPosition)}</span></p>
                <section class="restart-controls" aria-labelledby="restartHeading">
                    <h2 id="restartHeading">Bot controls</h2>
                    <p>${restartHint}</p>
                    <form id="restartForm" class="restart-row" autocomplete="off">
                        <input class="visually-hidden" type="text" name="username" autocomplete="username" value="admin" tabindex="-1" aria-hidden="true">
                        <label for="adminPassword">Admin password</label>
                        <input id="adminPassword" type="password" autocomplete="current-password" ${canRestart ? 'required minlength="16"' : 'disabled'}>
                        <button id="restartButton" type="submit" ${canRestart ? '' : 'disabled'}>Restart bot</button>
                    </form>
                    <p id="restartMessage" role="status" aria-live="polite"></p>
                </section>
            </div>
            <script>
                const restartEnabled = ${canRestart ? 'true' : 'false'};
                const restartForm = document.getElementById('restartForm');
                const restartButton = document.getElementById('restartButton');
                const passwordInput = document.getElementById('adminPassword');
                const restartMessage = document.getElementById('restartMessage');

                restartForm.addEventListener('submit', async function(event) {
                    event.preventDefault();
                    if (!passwordInput.value) {
                        restartMessage.textContent = 'Enter the admin password first.';
                        passwordInput.focus();
                        return;
                    }

                    restartButton.disabled = true;
                    restartMessage.textContent = 'Sending restart request...';
                    try {
                        const response = await fetch('/restart', {
                            method: 'POST',
                            headers: { 'Authorization': 'Bearer ' + passwordInput.value }
                        });
                        const result = await response.json();
                        restartMessage.textContent = result.message || 'Restart request completed.';
                    } catch (error) {
                        restartMessage.textContent = 'Could not reach the bot server. Check the connection and try again.';
                    } finally {
                        passwordInput.value = '';
                        restartButton.disabled = !restartEnabled;
                    }
                });

                async function refreshStatus() {
                    try {
                        const response = await fetch('/status', { cache: 'no-store' });
                        if (!response.ok) return;
                        const status = await response.json();
                        document.getElementById('botStatus').textContent = status.status;
                        document.getElementById('botPosition').textContent = status.position;
                    } catch (error) {
                        // Keep the current display if a periodic status request fails.
                    }
                }

                setInterval(refreshStatus, 5000);
            </script>
        </body>
        </html>
    `);
});

server.listen(PORT, '0.0.0.0', () => {
    console.log(`HTTP Server running on port ${PORT}`);
    if (botStatus === 'Initializing...') {
        botStatus = `HTTP Server running on port ${PORT}`;
    }
});

// Only connect from the published deployment; a workspace run would log in
// with the same Minecraft username and kick the published bot.
if (process.env.REPLIT_DEPLOYMENT === '1') {
    createBot();
} else {
    botStatus = 'Bot runs only in the published deployment';
    console.log('Skipping Minecraft connection in the development workspace.');
}
