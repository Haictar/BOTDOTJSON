# Minecraft Mineflayer bot

## Running
- Requires Node.js 22 or newer.
- Install dependencies with `npm install`.
- The development workflow serves the status page only. The bot connects only from its published deployment to avoid duplicate Minecraft logins.
- Publish as a Reserved VM to keep one bot process online. Do not run additional copies using the same Minecraft username.
- The HTTP status page listens on `0.0.0.0:5000` by default. `PORT` can override it.
- `/health` returns HTTP 200 while the bot is connected and HTTP 503 while it is disconnected, for uptime monitoring.
- `/status` returns the current public bot status and position as JSON.
- The status page updates every five seconds without reloading.
- Set `BOT_ADMIN_PASSWORD` in Replit Secrets to a value at least 16 characters long. The restart button accepts authenticated requests only in the published deployment and limits manual restarts to one every 30 seconds.

## Minecraft settings
The existing host, Minecraft port, bot username, teleport coordinates, and timers are defined near the top of `bot.js`. They have been preserved from the imported repository.

The configured Minecraft server must be online and reachable. The bot currently uses Mineflayer's default offline authentication; an online-mode server requires a valid Minecraft account and authentication configuration. Teleport commands require permission on the server.

The bot attempts reconnection ten seconds after disconnecting. Check the published deployment logs and the Minecraft server console for kick reasons. Keep the development workflow from connecting to Minecraft while the published bot is running; only one client can use the configured username at a time.
